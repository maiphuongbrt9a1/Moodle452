<?php

/**
 * Fixture file providing a class with a method without phpdoc.
 *
 * @package   local_moodlecheck
 * @copyright 2023 onwards Eloy Lafuente (stronk7) {@link https://stronk7.com}
 * @license   https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

class someclass extends parentclass {
    public function somefunc() {
    }
}
